﻿namespace mapgen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.generate = new System.Windows.Forms.Button();
            this.prbar = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.chance = new System.Windows.Forms.NumericUpDown();
            this.min_wall_w = new System.Windows.Forms.NumericUpDown();
            this.max_wall_w = new System.Windows.Forms.NumericUpDown();
            this.max_wall_h = new System.Windows.Forms.NumericUpDown();
            this.min_wall_h = new System.Windows.Forms.NumericUpDown();
            this.wigth = new System.Windows.Forms.TextBox();
            this.heigth = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.saveFile = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.chance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.min_wall_w)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.max_wall_w)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.max_wall_h)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.min_wall_h)).BeginInit();
            this.SuspendLayout();
            // 
            // generate
            // 
            this.generate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.generate.Location = new System.Drawing.Point(156, 109);
            this.generate.Name = "generate";
            this.generate.Size = new System.Drawing.Size(100, 36);
            this.generate.TabIndex = 0;
            this.generate.Text = "Generate!";
            this.generate.UseVisualStyleBackColor = true;
            this.generate.Click += new System.EventHandler(this.button1_Click);
            // 
            // prbar
            // 
            this.prbar.Location = new System.Drawing.Point(10, 151);
            this.prbar.Name = "prbar";
            this.prbar.Size = new System.Drawing.Size(246, 23);
            this.prbar.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Шанс генерації стіни:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(153, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Розмір карти";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Мін/мак висота стіни:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(153, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Ширина:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Мін/мак ширина стіни:";
            // 
            // chance
            // 
            this.chance.Location = new System.Drawing.Point(10, 25);
            this.chance.Name = "chance";
            this.chance.Size = new System.Drawing.Size(120, 20);
            this.chance.TabIndex = 10;
            this.chance.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // min_wall_w
            // 
            this.min_wall_w.Location = new System.Drawing.Point(10, 74);
            this.min_wall_w.Name = "min_wall_w";
            this.min_wall_w.Size = new System.Drawing.Size(51, 20);
            this.min_wall_w.TabIndex = 11;
            // 
            // max_wall_w
            // 
            this.max_wall_w.Location = new System.Drawing.Point(79, 74);
            this.max_wall_w.Name = "max_wall_w";
            this.max_wall_w.Size = new System.Drawing.Size(51, 20);
            this.max_wall_w.TabIndex = 12;
            // 
            // max_wall_h
            // 
            this.max_wall_h.Location = new System.Drawing.Point(79, 125);
            this.max_wall_h.Name = "max_wall_h";
            this.max_wall_h.Size = new System.Drawing.Size(51, 20);
            this.max_wall_h.TabIndex = 13;
            // 
            // min_wall_h
            // 
            this.min_wall_h.Location = new System.Drawing.Point(10, 125);
            this.min_wall_h.Name = "min_wall_h";
            this.min_wall_h.Size = new System.Drawing.Size(51, 20);
            this.min_wall_h.TabIndex = 14;
            // 
            // wigth
            // 
            this.wigth.Location = new System.Drawing.Point(156, 44);
            this.wigth.Name = "wigth";
            this.wigth.Size = new System.Drawing.Size(100, 20);
            this.wigth.TabIndex = 15;
            // 
            // heigth
            // 
            this.heigth.Location = new System.Drawing.Point(156, 83);
            this.heigth.Name = "heigth";
            this.heigth.Size = new System.Drawing.Size(100, 20);
            this.heigth.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(153, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Висота:";
            // 
            // saveFile
            // 
            this.saveFile.CreatePrompt = true;
            this.saveFile.DefaultExt = "map";
            this.saveFile.FileName = "default.map";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(268, 184);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.heigth);
            this.Controls.Add(this.wigth);
            this.Controls.Add(this.min_wall_h);
            this.Controls.Add(this.max_wall_h);
            this.Controls.Add(this.max_wall_w);
            this.Controls.Add(this.min_wall_w);
            this.Controls.Add(this.chance);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.prbar);
            this.Controls.Add(this.generate);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "TankMapGenerator";
            ((System.ComponentModel.ISupportInitialize)(this.chance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.min_wall_w)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.max_wall_w)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.max_wall_h)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.min_wall_h)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button generate;
        private System.Windows.Forms.ProgressBar prbar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown chance;
        private System.Windows.Forms.NumericUpDown min_wall_w;
        private System.Windows.Forms.NumericUpDown max_wall_w;
        private System.Windows.Forms.NumericUpDown max_wall_h;
        private System.Windows.Forms.NumericUpDown min_wall_h;
        private System.Windows.Forms.TextBox wigth;
        private System.Windows.Forms.TextBox heigth;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.SaveFileDialog saveFile;
    }
}

