﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace mapgen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            generate.Enabled = false;

            int w = Convert.ToInt32(wigth.Text);
            int h = Convert.ToInt32(heigth.Text);
            int chanc = Convert.ToInt32(chance.Value);
            int max_h = Convert.ToInt32(max_wall_h.Value);
            int min_h = Convert.ToInt32(min_wall_h.Value);
            int max_w = Convert.ToInt32(max_wall_w.Value);
            int min_w = Convert.ToInt32(min_wall_w.Value);
            double pb_temp = 0;

            StreamWriter map = new StreamWriter(@"default.map");
            Random rnd = new Random();

            int[][] mapp = new int[h][];
            for (int i = 0; i < h; i++)
            {
                pb_temp += 15.0 / h;
                prbar.Value = Convert.ToInt32(pb_temp);
                mapp[i] = new int[w];
                for (int j = 0; j < w; j++)
                    mapp[i][j] = 0;
            }
            
            for(int i = 0; i<h; i++)
                for (int j = 0; j < w; j++)
                {
                    pb_temp += 20.0 / (w * h);
                    prbar.Value = Convert.ToInt32(pb_temp);
                    if (mapp[i][j] == 1)
                        continue;
                    int ch = rnd.Next(0, 100);
                    if (ch > chanc/5)
                        continue;
                    else
                    {
                        int h_w = rnd.Next(min_h, max_h);
                        int w_w = rnd.Next(min_w, max_w);

                        for(int i_h = 0; i_h<h_w; i_h++)
                            for (int i_w = 0; i_w < w_w; i_w++)
                            {
                                if (i + i_h >= h || j + i_w >= w)
                                    continue;
                                mapp[i + i_h][j + i_w] = 1;
                            }
                    }
                }

            map.WriteLine(h.ToString() + " " + w.ToString());

            for (int i = 0; i < h; i++)
            {
                String buff = "";
                pb_temp += 65.0  / h;
                prbar.Value = Convert.ToInt32(pb_temp);
                for (int j = 0; j < w; j++)
                {
                    buff += mapp[i][j].ToString() + ((j+1==w)?"":" ").ToString();
                }
                map.WriteLine(buff);
            }
            prbar.Value = 0;
            map.Close();

            generate.Enabled = true;
        }
    }
}
