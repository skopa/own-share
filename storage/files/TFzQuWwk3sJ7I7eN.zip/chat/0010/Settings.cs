﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;

namespace _0010
{
    class Settings
    {
        readonly Socket _s;
        public delegate void ReceivedEventHandler(Settings cs, string received);
        public event ReceivedEventHandler Received = delegate { };
        public event EventHandler Connected = delegate {};
        public delegate void DisconnectedEventHandler(Settings cs);
        public event DisconnectedEventHandler Disconnected = delegate {};
        bool _connected;
    }
}
