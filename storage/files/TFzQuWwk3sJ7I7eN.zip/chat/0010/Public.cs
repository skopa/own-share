﻿using PostRequest;
using SocketIO;
using System;
using System.Collections.Generic;
using System.Windows.Forms;


namespace _0010
{
    public partial class Public : Form
    {
        private Socket socket;
        private History history;

        private List<MessageContainer> MessagesHistory;

        delegate void SocketMessageCallback(string message, string user = "");
        delegate void ChangeStatusCallback(string status);
        public Public()
        {
            InitializeComponent();
            InitializeSocket();
            InitializeHistory();
        }

        private void InitializeSocket()
        {
            socket = new Socket("http://api.tml.skop.in.ua:3011");

            socket.On("connect", (d) =>
            {
                this.ChangeStatus("Connected");
                Console.WriteLine("Connected");
                Dictionary<string, object> arg = new Dictionary<string, object>();
                arg.Add("token", User.GetInstanse().GetHash());
                socket.Emit("login", arg);
            });

            socket.On("disconnect", () =>
            {
                this.ChangeStatus("Offline");
            });

            socket.On("error", (data) =>
            {
                MessageBox.Show(data.ToString());
                this.ChangeStatus("Error");
            });

            socket.On("logged", (data) =>
            {
                if (data["status"].ToString() == "OK")
                {
                    this.ChangeStatus("Online");
                }
            });

            socket.On("ChatEvent", (data) =>
            {
                this.AppendMessage(data["message"].ToString(), data["user"].ToString());
            });

            socket.Connect();
        }

        private void ChangeStatus(string status)
        {
            if (this.conn_status.InvokeRequired)
            {
                this.Invoke(
                    new ChangeStatusCallback(ChangeStatus),
                    new object[] { status });
            }
            else
            {
                this.conn_status.Text = status;
            }
        }

        private void AppendMessage(string message, string user = "Guest")
        {
            if (this.mes_lst.InvokeRequired)
            {
                this.Invoke(
                    new SocketMessageCallback(AppendMessage),
                    new object[] { message, user });
            }
            else
            {
                this.mes_lst.AppendText(user + ">" + message + Environment.NewLine);
            }
        }

        private void SendMessage()
        {
            POST r = new POST("http://api.tml.skop.in.ua/api/socket/client/message");

            r
                .AddParam("message", mes_box.Text)
                .AddParam("hash", User.GetInstanse().GetHash());

            if (r.Send())
            {
                Response resp = r.GetResponse();
                if (resp.status != "ok")
                {
                    MessageBox.Show(resp.response);
                }
            }
            else
            {
                MessageBox.Show("Internet connection error");
            }
        }

        private void InitializeHistory()
        {
            this.history = new History("http://api.tml.skop.in.ua/api/socket/client/message");
            if (history.Get())
            {
                this.MessagesHistory = new List<MessageContainer>(this.history.GetMessages());
                MessagesHistory.ForEach((message) =>
                {
                    this.AppendMessage(message.message, message.user);
                });
                this.mes_lst.SelectionStart = mes_lst.TextLength;
                this.mes_lst.ScrollToCaret();
            }
        }

        private void send_btm_Click(object sender, EventArgs e)
        {
            this.SendMessage();
            this.mes_box.Text = "";
        }

        private void logout_btn_Click(object sender, EventArgs e)
        {
            this.Close();
            Login f1 = new Login();
            f1.Show();
        }

        private void Public_FormClosing(object sender, FormClosedEventArgs e)
        {
            socket.Disconnect();
            Application.Exit();
        }

        private void mes_box_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                send_btm.PerformClick(); ;
            }
        }

        private void conn_status_Click(object sender, EventArgs e)
        {

        }

        private void Public_SizeChanged(object sender, EventArgs e)
        {
      
            }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
        }

        private void Public_Load(object sender, EventArgs e)
        {
        
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Public_Move(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Hide();
                //contextMenuStrip1.Show();
              
            }
            }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }
    }
    }
    

