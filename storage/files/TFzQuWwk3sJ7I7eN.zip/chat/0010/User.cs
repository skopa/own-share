﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0010
{
    class User
    {
        private static User user = null;
        private string hash;

        public static User GetInstanse()
        {
            if (user == null)
                user = new User();
            return user;
        }

        public string GetHash()
        {
            return this.hash;
        }

        public void SetHash(string hash)
        {
            this.hash = hash;
        }
    }
}
