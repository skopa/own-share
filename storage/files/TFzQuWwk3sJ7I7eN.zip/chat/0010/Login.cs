﻿using System;
using PostRequest;
using System.Windows.Forms;

namespace _0010
{
    public partial class Login : Form
    {
        

        public Login()
        {
            //0010 = new Settings();
            InitializeComponent();
            this.ActiveControl = username_bx;
            username_bx.Focus();
        }

        private void username_bx_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                password_bx.Focus();
            }
        }

        private void password_bx_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                Sign_in_btm.PerformClick(); ;
            }
        }

        private void Sign_in_btm_Click(object sender, EventArgs e)
        {
            if (username_bx.Text == "" || password_bx.Text == "")
            {
                MessageBox.Show("Please provide User name and Password");
                return;
            }

            try
            {
                POST r = new POST("http://api.tml.skop.in.ua/api/socket/client/login");

                r
                    .AddParam("login", username_bx.Text)
                    .AddParam("password", password_bx.Text);
                if (r.Send())
                {
                    Response resp = r.GetResponse();
                    if (resp.status == "ok")
                    {
                        User.GetInstanse().SetHash(resp.response);
                        this.Hide();
                        Public form = new Public();
                        form.Disposed += (ev, d) =>
                        {
                            this.Close();
                        };
                        form.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid login or password");
                    }
                }
                else
                {
                    MessageBox.Show("Internet connection error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                password_bx.UseSystemPasswordChar = false;
            }
            else
            {
                password_bx.UseSystemPasswordChar = true;
            }

        }

        private void linkLabel1_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://tml.skop.in.ua/");
            }
            catch { }

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}

  