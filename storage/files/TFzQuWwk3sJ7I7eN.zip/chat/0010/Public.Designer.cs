﻿namespace _0010
{
    partial class Public
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Public));
            this.mes_box = new System.Windows.Forms.TextBox();
            this.mes_lst = new System.Windows.Forms.TextBox();
            this.send_btm = new System.Windows.Forms.Button();
            this.logout_btn = new System.Windows.Forms.Button();
            this.conn_status = new System.Windows.Forms.Label();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.showToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mes_box
            // 
            this.mes_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mes_box.Location = new System.Drawing.Point(12, 355);
            this.mes_box.Multiline = true;
            this.mes_box.Name = "mes_box";
            this.mes_box.Size = new System.Drawing.Size(328, 31);
            this.mes_box.TabIndex = 0;
            this.mes_box.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mes_box_KeyDown);
            // 
            // mes_lst
            // 
            this.mes_lst.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mes_lst.BackColor = System.Drawing.Color.White;
            this.mes_lst.Location = new System.Drawing.Point(8, 40);
            this.mes_lst.Multiline = true;
            this.mes_lst.Name = "mes_lst";
            this.mes_lst.ReadOnly = true;
            this.mes_lst.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.mes_lst.Size = new System.Drawing.Size(429, 300);
            this.mes_lst.TabIndex = 1;
            // 
            // send_btm
            // 
            this.send_btm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.send_btm.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.send_btm.Location = new System.Drawing.Point(357, 355);
            this.send_btm.Name = "send_btm";
            this.send_btm.Size = new System.Drawing.Size(80, 31);
            this.send_btm.TabIndex = 2;
            this.send_btm.Text = "SEND";
            this.send_btm.UseVisualStyleBackColor = true;
            this.send_btm.Click += new System.EventHandler(this.send_btm_Click);
            // 
            // logout_btn
            // 
            this.logout_btn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.logout_btn.Location = new System.Drawing.Point(388, 12);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(56, 22);
            this.logout_btn.TabIndex = 3;
            this.logout_btn.Text = "Log out";
            this.logout_btn.UseVisualStyleBackColor = true;
            this.logout_btn.Click += new System.EventHandler(this.logout_btn_Click);
            // 
            // conn_status
            // 
            this.conn_status.AutoSize = true;
            this.conn_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.conn_status.Location = new System.Drawing.Point(10, 16);
            this.conn_status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.conn_status.Name = "conn_status";
            this.conn_status.Size = new System.Drawing.Size(43, 13);
            this.conn_status.TabIndex = 4;
            this.conn_status.Text = "Status";
            this.conn_status.Click += new System.EventHandler(this.conn_status_Click);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.contextMenuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(153, 70);
            this.contextMenuStrip1.UseWaitCursor = true;
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // showToolStripMenuItem
            // 
            this.showToolStripMenuItem.Name = "showToolStripMenuItem";
            this.showToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.showToolStripMenuItem.Text = "Show";
            this.showToolStripMenuItem.Click += new System.EventHandler(this.showToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // Public
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(456, 406);
            this.Controls.Add(this.conn_status);
            this.Controls.Add(this.logout_btn);
            this.Controls.Add(this.send_btm);
            this.Controls.Add(this.mes_lst);
            this.Controls.Add(this.mes_box);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Public";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Chat-Client";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Public_FormClosing);
            this.Load += new System.EventHandler(this.Public_Load);
           // this.SizeChanged += new System.EventHandler(this.Public_SizeChanged);
            this.Move += new System.EventHandler(this.Public_Move);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox mes_box;
        private System.Windows.Forms.TextBox mes_lst;
        private System.Windows.Forms.Button send_btm;
        private System.Windows.Forms.Button logout_btn;
        private System.Windows.Forms.Label conn_status;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}

