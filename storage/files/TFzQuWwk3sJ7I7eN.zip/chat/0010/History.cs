﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;


namespace _0010
{
    public class History
    {
        private string url, response;
        private MessageContainer[] messages = null;

        public History(string url)
        {
            this.url = url;
        }
        public bool Get()
        {
            try
            {
                WebRequest request = WebRequest.Create(this.url);
                WebResponse response = request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                this.response = reader.ReadToEnd();
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                this.messages = serializer.Deserialize<List<MessageContainer>>(this.response).ToArray();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Data);
            }
            return false;
        }

        public MessageContainer[] GetMessages()
        {
            return messages;
        }
    }
}
