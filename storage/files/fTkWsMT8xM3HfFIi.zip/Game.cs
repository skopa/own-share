﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace $safeprojectname$
{
    public class Game
    {
        // dll version
        public static float version = 0.01F;

        // result of test (on end working Play() method must contain result of test)
        public int Score;
        public int Steps;
        public int MemberCount;

        private XElement RootXml; 
        private TextWriter LogTextWriter;

        // costructor (don't get any attributes)
        // can contain primary init independent doings
        public Game()
        {
            RootXml = new XElement("xml");
            // TO DO
        }

        // call after all bots are loaded
        // folder - path to folder wрich contain bots *.exe files
        // textWriter - stream which is written game log
        public bool Init(string folder, TextWriter textWriter)
        {
            this.LogTextWriter = textWriter;
            // TO DO

            return true;
        }

        // call after succes init, must run test
        public void Play()
        {
            // TO DO

            // save xml
            this.RootXml.Save(LogTextWriter);
        }
    }
}
