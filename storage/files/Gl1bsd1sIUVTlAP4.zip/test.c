/* fgetwc example */
#include <stdio.h>
#include <stdlib.h>


#include "radiusclient.h"

int logToFile(VALUE_PAIR *s) {
    VALUE_PAIR *send = s;
    FILE *fo;
    fo = fopen("/home/stepan/test/log.txt", "a");

    while (send->next) {
        fprintf(fo, "%s, %i : %s \n", send->name, send->attribute, send->strvalue);
        send = send->next;
    }
    fprintf(fo, "File has been created...\n");
    fclose(fo);
    return 0;
}

void logToF() {
    FILE *fo;
    fo = fopen("/home/stepan/test/log.txt", "a");
    int t = fprintf(fo, "Start");
    fclose(fo);
    return;
}