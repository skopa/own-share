#include "nxjson.h"

struct string *getConfig() {
    return newString("{"
                             "\"api_url\":\"skop.in.ua/pptp/api\", "
                             "\"api_key\":\"test_key\", "
                             "\"session_timeout\":300"
                             "}");
}

char *getConfigString(char* name) {
    const nx_json* json=nx_json_parse(getChar(getConfig()), 0);

    if (json) {
        const char* v = nx_json_get(json, name)->text_value;
        nx_json_free(json);
        return (char*)v;
    }

    return "";
}


int getConfigInt(char* name) {
    const nx_json* json=nx_json_parse(getChar(getConfig()), 0);

    if (json) {
        long int v = nx_json_get(json, name)->int_value;
        nx_json_free(json);
        return (int)v;
    }

    return -1;
}