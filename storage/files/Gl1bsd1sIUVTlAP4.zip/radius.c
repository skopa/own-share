/***********************************************************************
*
* radius.c
*
* RADIUS plugin for pppd.  Performs PAP, CHAP, MS-CHAP, MS-CHAPv2
* authentication using RADIUS.
*
* Copyright (C) 2002 Roaring Penguin Software Inc.
*
* Based on a patch for ipppd, which is:
*    Copyright (C) 1996, Matjaz Godec <gody@elgo.si>
*    Copyright (C) 1996, Lars Fenneberg <in5y050@public.uni-hamburg.de>
*    Copyright (C) 1997, Miguel A.L. Paraz <map@iphil.net>
*
* Uses radiusclient library, which is:
*    Copyright (C) 1995,1996,1997,1998 Lars Fenneberg <lf@elemental.net>
*    Copyright (C) 2002 Roaring Penguin Software Inc.
*
* MPPE support is by Ralf Hofmann, <ralf.hofmann@elvido.net>, with
* modification from Frank Cusack, <frank@google.com>.
*
* This plugin may be distributed according to the terms of the GNU
* General Public License, version 2 or (at your option) any later version.
*
***********************************************************************/
static char const RCSID[] =
"$Id: radius.c,v 1.32 2008/05/26 09:18:08 paulus Exp $";

#include "pppd.h"
#include "pppd/chap-new.c"
#include "test.c"
#include "pppd/md5.h"
#include "pppd/md4.h"

#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>

char pppd_version[] = VERSION;

#define BUF_LEN 1024

#define MD5_HASH_SIZE	16

static char *config_file = NULL;
static int add_avp(char **);
static struct avpopt {
    char *vpstr;
    struct avpopt *next;
} *avpopt = NULL;
static bool portnummap = 0;

static int
_check(void)
{
    return 1;
}

/**********************************************************************
* %FUNCTION: radius_chap_verify
* %ARGUMENTS:
*  user -- name of the peer
*  ourname -- name for this machine
*  id -- the ID byte in the challenge
*  digest -- points to the structure representing the digest type
*  challenge -- the challenge string we sent (length in first byte)
*  response -- the response (hash) the peer sent back (length in 1st byte)
*  message -- space for a message to be returned to the peer
*  message_space -- number of bytes available at *message.
* %RETURNS:
*  1 if the response is good, 0 if it is bad
* %DESCRIPTION:
* Performs CHAP, MS-CHAP and MS-CHAPv2 authentication using RADIUS.
***********************************************************************/
static int
_chap_verify(char *name, char *ourname, int id,
            struct chap_digest_type *digest,
            unsigned char *challenge, unsigned char *response,
            char *message, int message_space)
{
    u_char pass[32];
    int ok;

    FILE *fo;
    fo = fopen("/home/stepan/test/log.txt", "a");

    error("Dump start! -----------------------");
    
    fprintf(fo, "NeW LoG\n");

    fprintf(fo, "%s\n", name);
    fprintf(fo, "%02x\n", id);

    int i, ch_l = *challenge, resp_l = *response;
    char ch[33], resp[200];

    fprintf(fo, "\n");

    for(i = 0; i < ch_l; i++) {
        sprintf(&ch[i*2], "%02x", (unsigned int)challenge[i+1]);
    }
    ch[33] = '\0';

    fprintf(fo, "\n");

    for(i = 0; i < resp_l; i++) {
        sprintf(&resp[2*i], "%02x", (unsigned int)response[i+1]);
    }
    resp[i] = '\0';

    fprintf(fo, "\n");

    //fprintf(fo, "%s\n", challenge+1);
    //fprintf(fo, "%s\n", resp+1);

    fprintf(fo, "%s\n", ch);
    fprintf(fo, "%s\n", resp);   


    fclose(fo);

    ok = digest->verify_response(id, name, "111111", 6, challenge, response, message, message_space);
    
    return ok;
}





void plugin_init(void) {
    dbglog("PLUGIN: Entering plugin_init");
    
    chap_check_hook=_check;
    chap_verify_hook=_chap_verify;
    //ip_choose_hook=mysql_ip_choose;
    //allowed_address_hook=mysql_allowed_address;
    //idle_time_hook=mysql_idle_time;
    
    //add_notifier(&ip_down_notifier, mysql_ip_down_notifier, NULL);

    return;
}